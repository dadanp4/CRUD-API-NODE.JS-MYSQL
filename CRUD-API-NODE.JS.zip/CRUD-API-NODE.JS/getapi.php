<?php

$url = "http://localhost:3000/pendapatan";

$json = file_get_contents($url);
$result = json_decode($json);
$total = count($result);

echo "

<table style='width:100%; text-align: center' border='1'>
  <tr>
    <th>ID Penjualan</th>
    <th>ID Piutang</th> 
    <th>Tanggal</th>
    <th>Total Pembayaran</th>
  </tr>
";

for ($i=0; $i < $total ; $i++) { 
    echo "    
            <tr>
                <td>".$result[$i]->idpenjualan."</td>
                <td>".$result[$i]->idpiutang."</td>
                <td>".$result[$i]->date."</td>
                <td>".$result[$i]->totalpendapatan."</td>
            </tr>

    ";
}

echo "</table>";


?>