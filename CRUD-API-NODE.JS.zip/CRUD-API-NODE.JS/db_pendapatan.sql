-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 10 Nov 2020 pada 12.21
-- Versi server: 10.1.40-MariaDB
-- Versi PHP: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_pendapatan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_pendapatan`
--

CREATE TABLE `tbl_pendapatan` (
  `idpendapatan` int(11) NOT NULL,
  `idpenjualan` int(11) NOT NULL,
  `idpiutang` int(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `totalpendapatan` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_pendapatan`
--

INSERT INTO `tbl_pendapatan` (`idpendapatan`, `idpenjualan`, `idpiutang`, `date`, `totalpendapatan`) VALUES
(1, 22, 22, '2020-04-23', 700000),
(2, 23, 23, '2020-04-23', 90000),
(3, 24, 24, '2020-07-25', 78000),
(4, 25, 25, '2020-07-29', 33000);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tbl_pendapatan`
--
ALTER TABLE `tbl_pendapatan`
  ADD PRIMARY KEY (`idpendapatan`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tbl_pendapatan`
--
ALTER TABLE `tbl_pendapatan`
  MODIFY `idpendapatan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
