const sql = require("./db.js");

const Pendapatan = function(pendapatan) {
  this.idpenjualan = pendapatan.idpenjualan;
  this.idpiutang = pendapatan.idpiutang;
  this.date = pendapatan.date;
  this.totalpendapatan = pendapatan.totalpendapatan;
};

Pendapatan.create = (newPendapatan, result) => {
  sql.query("INSERT INTO tbl_pendapatan SET ?", newPendapatan, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    console.log("pendapatan tertambah: ", { id: res.insertId, ...newPendapatan });
    result(null, { id: res.insertId, ...newPendapatan });
  });
};

Pendapatan.findById = (pendapatanId, result) => {
  sql.query(`SELECT * FROM tbl_pendapatan WHERE idpendapatan = ${pendapatanId}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      console.log("pendapatan ditemukan : ", res[0]);
      result(null, res[0]);
      return;
    }

    result({ kind: "tidak ditemukan" }, null);
  });
};

Pendapatan.getAll = result => {
  sql.query("SELECT * FROM tbl_pendapatan", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log("pendapatan: ", res);
    result(null, res);
  });
};

Pendapatan.updateById = (id, pendapatan, result) => {
  sql.query(
    "UPDATE tbl_pendapatan SET idpenjualan = ?, idpiutang = ?, date = ?, totalpendapatan = ?  WHERE idpendapatan = ?",
    [pendapatan.idpenjualan, pendapatan.idpiutang, pendapatan.date, pendapatan.totalpendapatan, id],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }

      if (res.affectedRows == 0) {
        result({ kind: "tidak ditemukan" }, null);
        return;
      }

      console.log("pendapatan terubah: ", { id: id, ...pendapatan });
      result(null, { id: id, ...pendapatan });
    }
  );
};

Pendapatan.remove = (id, result) => {
  sql.query("DELETE FROM tbl_pendapatan WHERE idpendapatan = ?", id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      result({ kind: "tidak ditemukan" }, null);
      return;
    }

    console.log("id pendapatan "+id+" telah terhapus");
    result(null, res);
  });
};

Pendapatan.removeAll = result => {
  sql.query("DELETE FROM tbl_pendapatan", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`${res.affectedRows} pendapatan terhapus`);
    result(null, res);
  });
};

module.exports = Pendapatan;