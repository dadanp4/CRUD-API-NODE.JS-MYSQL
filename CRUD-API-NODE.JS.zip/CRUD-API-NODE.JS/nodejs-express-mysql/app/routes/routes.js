module.exports = app => {
    const pendapatan = require("../controller/controller.js");
  
    app.post("/pendapatan", pendapatan.create);
  
    app.get("/pendapatan", pendapatan.findAll);
  
    app.get("/pendapatan/:Idpendapatan", pendapatan.findOne);
  
    app.put("/pendapatan/:Idpendapatan", pendapatan.update);
  
    app.delete("/pendapatan/:Idpendapatan", pendapatan.delete);
  
    app.delete("/pendapatan", pendapatan.deleteAll);
  };