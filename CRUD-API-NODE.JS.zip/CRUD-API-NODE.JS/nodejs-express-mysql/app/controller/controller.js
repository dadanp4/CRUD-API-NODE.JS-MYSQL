const Pendapatan = require("../models/models.js");

exports.create = (req, res) => {
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  const pendapatan = new Pendapatan({
    idpenjualan: req.body.idpenjualan,
    idpiutang: req.body.idpiutang,
    date: req.body.Date,
    totalpendapatan: req.body.totalpendapatan
  });

  Pendapatan.create(pendapatan, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the pendapatan."
      });
    else res.send(data);
  });  
};

exports.findAll = (req, res) => {
    Pendapatan.getAll((err, data) => {
        if (err)
          res.status(500).send({
            message:
              err.message || "Beberapa kesalahan terjadi saat mengambil data pendapatan."
          });
        else res.send(data);
      });
};

exports.findOne = (req, res) => {
    Pendapatan.findById(req.params.Idpendapatan, (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(404).send({
              message: `id pendapatan tidak ditemukan ${req.params.Idpendapatan}.`
            });
          } else {
            res.status(500).send({
              message: "id pendapatan tidak ditemukan " + req.params.Idpendapatan
            });
          }
        } else res.send(data);
      });
};

exports.update = (req, res) => {

    if (!req.body) {
        res.status(400).send({
          message: "Content can not be empty!"
        });
      }
    
      Pendapatan.updateById(
        req.params.Idpendapatan,
        new Pendapatan(req.body),
        (err, data) => {
          if (err) {
            if (err.kind === "not_found") {
              res.status(404).send({
                message: `id pendapatan tidak ditemukan ${req.params.Idpendapatan}.`
              });
            } else {
              res.status(500).send({
                message: "Error updating pendapatan with id " + req.params.Idpendapatan
              });
            }
          } else res.send(data);
        }
      );
};

exports.delete = (req, res) => {
    Pendapatan.remove(req.params.Idpendapatan, (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(404).send({
              message: `id pendapatan tidak ditemukan ${req.params.Idpendapatan}.`
            });
          } else {
            res.status(500).send({
              message: "Could not delete pendapatan with id " + req.params.Idpendapatan
            });
          }
        } else res.send({ message: `pendapatan was deleted successfully!` });
      });
};

exports.deleteAll = (req, res) => {
    Pendapatan.removeAll((err, data) => {
        if (err)
          res.status(500).send({
            message:
              err.message || "Some error occurred while removing all pendapatan."
          });
        else res.send({ message: `Menghapus semua data pendapatan berhasil` });
      });
};